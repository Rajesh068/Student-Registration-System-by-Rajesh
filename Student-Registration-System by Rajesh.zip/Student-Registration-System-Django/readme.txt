How to Run the Project

Install Python (How to install Python:  https://pythongurukul.in/python-tutorials/python-installation/)

Install Django : python -m pip install Django

Open the project in PyCharm and go the project directory

Finally, Run the command: pyhton manage.py runserver

*********For Django Admin Login**********
URL: http://127.0.0.1:8000/admin/
Username: admin
Password: 123